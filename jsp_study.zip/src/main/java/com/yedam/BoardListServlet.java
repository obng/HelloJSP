package com.yedam;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceImpl;
import com.yedam.vo.BoardVO;

@WebServlet("/BoardListServlet")
public class BoardListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public BoardListServlet() {
        super();
        System.out.println("BoardListServlet 생성자");
    }

	protected void doGet(HttpServletRequest request, // 요청 정보
			HttpServletResponse response) // 응답 정보
					throws ServletException, IOException {
		// 글 목록 출력
		System.out.println("Hello Servlet");
		
		// content Type을 따로 지정을 하지 않으면 텍스트 타입임
		// 따로 지정을 해면 됨
		// html로 지정 -> html 태그를 사용할 수 있음
		response.setContentType("text/html; charset=utf-8");
		
		
		// getWriter -> 출력 stream -> out.println을 하면 그때 웹 페이지에 출력함
		// System.out.println -> 콘솔에 출력
		PrintWriter out = response.getWriter(); // stream
		out.println("<b>Hello, Servlet</b>");
		
		BoardService svc = new BoardServiceImpl();
		List<BoardVO> list = svc.boardList();
		
		String html = "<table border='2'><thead><tr><th>글번호</th>"
									  + "<th>제목</th>"
									  + "<th>작성자</th>"
									  + "<th>조회수</th>"
									  + "</tr></thead>";
		html += "<tbody>";
		
		for (BoardVO board : list) {
			html += "<tr><td align='center'><a href='board?board_no=" + board.getBoardNo() + "'>" + board.getBoardNo() + "</a></td>"
				  + "<td>" + board.getTitle() + "</td>"
				  + "<td>" + board.getWriter() + "</td>"
				  + "<td>" + board.getViewCnt() + "</td></tr>";
		}
		
		html += "</tbody></table>";
			
		out.println(html);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
