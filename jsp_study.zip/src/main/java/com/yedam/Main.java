package com.yedam;

import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceImpl;
import com.yedam.vo.BoardVO;

public class Main {

	public static void main(String[] args) {
		
		BoardService svc = new BoardServiceImpl(); // 업무 기능
		
		int searchNo = 1;
		
		// 조회, 조회수 증가 -> 업무(조회: 글번호 조회 + 조회카운트) -> 같이 동작해야 하는 코드들을 업무 형태로 묶어서 만드는 것이 -> Servse
		BoardVO board = svc.searchBoard(searchNo);
		
		System.out.println(board.toString());

	}

}
