package com.yedam.service;

import java.util.List;

import com.yedam.vo.BoardVO;

//조회, 조회수 증가 -> 업무(조회: 글번호 조회 + 조회카운트) -> 같이 동작해야 하는 코드들을 업무 형태로 묶어서 만드는 것이 -> Servse
public interface BoardService {
	public List<BoardVO> boardList(); // 업무 단위 표기
	public BoardVO searchBoard(int boardNo); // 조회(조회 + 카운트증가)
	public boolean registerBoard(BoardVO board);
	public boolean removeBoard(int boardNo);
}
