package com.yedam;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceImpl;
import com.yedam.vo.BoardVO;

// 서블릿의 실행 순서
// 페이지: 75
// live Server:
// client -> 웹 서버(정적 페이지) -> 서블릿컨테이너(톰켓) -> init() -> service()
// init(): 요청시 최초 한번만 실행
// service(): 요청시 매번 실행

@WebServlet("/board")
public class BoardServlet extends HttpServlet {
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init() 메소드 호출");
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		if (req.getMethod().equals("GET")) {
			// get -> 조회
			
			resp.setContentType("text/html; charset=utf-8");
			
			System.out.println("service() 메소드 호출");
			
			// http://localhost:8080/HelloJSP/board?board_no=3&writer=user01
			
			String board_no = req.getParameter("board_no"); // "3"
			int bno = Integer.parseInt(board_no); // "3" -> 3
			
			BoardService svc = new BoardServiceImpl();
			BoardVO board = svc.searchBoard(bno);
			
			// 글번호: 3		제목: ???
			// 내용: 안녕 어쩌구 저쩌구
			// 작성자: 홍길동
			// 작성일자: 2025.07.25 13:22:18
			
			String html = "<table border='1'>";
			html += "<tr><th>글번호</th><td>" + board.getBoardNo() + 
					"</td><th>제목</th><td>" + board.getTitle() +
					"</td><tr><th>내용</th><td <td colspan='3'>" + board.getContent() +
					"</td></tr><tr><th>작성자</th><td colspan='3'>" + board.getWriter() +
					"</td></tr><tr><th>작성일자</th><td colspan='3'>" + board.getCreationDate() + "</td></tr>";
			html += "</table>";
			
			html += "<div><a href='DeleteBoard?board_no=" + board.getBoardNo() + "'>글삭제</a></div>";
			html += "<a href='./BoardListServlet'>목록가기</a>";
			
			resp.getWriter().print(html);
		}
		else if (req.getMethod().equals("POST")) {
			// post -> 등록
			
			// 요청 정보의 인코딩 지정
			req.setCharacterEncoding("utf-8"); // 한글 처리
			
			String title = req.getParameter("title");
			String content = req.getParameter("content");
			String writer = req.getParameter("writer");
			
			// BoradVO 파라미터
			BoardVO param = new BoardVO();
			param.setTitle(title);
			param.setContent(content);
			param.setWriter(writer);

			BoardService svc = new BoardServiceImpl();
			if (svc.registerBoard(param)) {
				// 목록
				resp.sendRedirect("BoardListServlet");
				
			}
			else {
				System.out.println("에러 발생"); // 에러 페이지 (jsp)
			}
		}
		
	}
}
